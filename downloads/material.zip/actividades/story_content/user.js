function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5w54n3j1j8E":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

